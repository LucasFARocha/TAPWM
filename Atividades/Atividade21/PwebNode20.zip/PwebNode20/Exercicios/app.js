var express = require('express');
var app = express();

app.set('view engine', 'ejs');

// app.get('/', function(req, res){
//     res.send('<html><body><h1>Site da Fatec Sorocaba</h1></body></html>');
// });
// app.get('/cursos', function(req, res){
//     res.render('secao/cursos');
// });
// app.get('/professores', function(req, res){
//     res.render('secao/professores');
// });
// app.get('/historia', function(req, res){
//     res.render('secao/historia');
// });

// app.listen(3000, function(){
//     console.log('servidor com express foi carregado');
// });

app.get('/', function(req, res){
    res.render('home/index');
});

app.get('/formulario-adicionar-usuario', function(req, res){
    res.render('admin/adicionar_usuario');
});

app.get('/informacao/cursos', function(req, res){
    res.render('informacao/cursos');
});

app.get('/informacao/historia', function(req, res){
    res.render('informacao/historia');
});

app.get('/informacao/professores', function(req, res){
    res.render('informacao/professores');
});

app.listen(3000, function(){
    console.log('servidor com express foi carregado');
});