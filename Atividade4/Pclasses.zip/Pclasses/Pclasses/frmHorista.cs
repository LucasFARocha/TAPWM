﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        
        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Horista horista = new Horista();

            horista.NomeEmpregado = txtNome.Text;
            horista.Matricula = Convert.ToInt32(txtMatricula.Text);
            horista.SalarioHora = Convert.ToInt32(txtSalario.Text);
            horista.NumeroHora = Convert.ToDouble(txtHoras.Text);
            horista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrada.Text);
            horista.DiasFalta = Convert.ToInt32(txtDiasFaltas.Text);

            MessageBox.Show("Nome: " + horista.NomeEmpregado +
                "\nMatrícula: " + horista.Matricula +
                "\nTempo de Trabalho: " + horista.TempoTrabalho().ToString() + " dias" +
                //Se não colocar o ToString() no TempoTrabalho ele converte implicitamente
                "\nSalário Final: R$" + horista.SalarioBruto().ToString("N2"));
        }
    }
}
